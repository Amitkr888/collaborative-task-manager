
import express from 'express'
import http from 'http'
import { Server } from 'socket.io'

const app = express()
app.use(express.json())

const server = http.createServer(app)
const io = new Server(server, { cors: { origin: '*' } })

io.on('connection', (socket) => {
  console.log('User connected:', socket.id)
})

app.get('/health', (_, res) => {
  res.json({ status: 'OK' })
})

server.listen(4000, () => {
  console.log('Backend running on port 4000')
})
