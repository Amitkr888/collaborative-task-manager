
# Collaborative Task Manager

## Setup

### Frontend
cd frontend
npm install
npm run dev

### Backend
cd backend
npm install
npm run dev
